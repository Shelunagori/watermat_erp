<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PunchAttendances Controller
 *
 * @property \App\Model\Table\PunchAttendancesTable $PunchAttendances
 *
 * @method \App\Model\Entity\PunchAttendance[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PunchAttendancesController extends AppController
{
}
